
package com.mycompany.p1tarea2_chuico_jimenez_risco;

import java.util.Scanner;

public class P1Tarea2_Chuico_Jimenez_Risco {

    public static void main(String[] args) {
        Restaurante restaurante = new Restaurante( 2);
        restaurante.guardarMenu();
        restaurante.Acciones();
    }
}
